# -*- coding: utf-8 -*-
"""Build the LTC-Topology reproducibility package v2.
Copies code / protocol / manifests / results / analysis / checkpoints with
SHA-256 verification, and emits package_manifest.json + checkpoints_manifest.json.
"""
import hashlib, json, os, shutil, sys, time
sys.stdout.reconfigure(encoding="utf-8")

PROJ = r"E:\AMASS_LNN_Project"
B33 = os.path.join(PROJ, r"runs\formal_reviewer_minimum33_revision_20260823")
B15 = os.path.join(PROJ, r"runs\formal_protocol_v2_subject_grouped_rootrel_pose_20260815")
SUBMIT = r"C:\Users\1\Desktop\返修提交终稿_20260915"
PKG = r"C:\Users\1\Desktop\ltc_topology_reproducibility_v2"

def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()

def copy_retry(src, dst, tries=8):
    for i in range(tries):
        try:
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            shutil.copy2(src, dst)
            return
        except OSError as e:
            if i == tries - 1:
                raise
            time.sleep(3 + 3 * i)

MANIFEST = {}   # relpath -> sha256
CHECKPOINT_MANIFEST = {}

def add(src, dst, checkpoint=False):
    copy_retry(src, dst)
    h = sha256(dst)
    rel = os.path.relpath(dst, PKG).replace("\\", "/")
    (CHECKPOINT_MANIFEST if checkpoint else MANIFEST)[rel] = h
    print(f"  + {rel}  ({h[:12]})")

print("== code: src/ ==")
for e in os.scandir(os.path.join(PROJ, "src")):
    if e.name.endswith(".py"):
        add(e.path, os.path.join(PKG, "code", "src", e.name))

print("== code: frozen-inventory entrypoints (root) ==")
INV = json.load(open(os.path.join(B33, r"reused\reused_inventory.json"), encoding="utf-8"))
ROOT_SCRIPTS = {
    "build_reviewer_minimum33_plan_20260823.py",
    "train.py",
    "train_ltc_topology_rollout_consistency.py",
    "train_protocol_v2_revision_20260821.py",
    "train_protocol_v2_revision_hisrep_20260821.py",
    "train_hisrep_cmu_clean.py",
    "train_protocol_v2_reviewer_baseline_20260822.py",
    "train_reviewer_ltc_legacy_compatible_20260822.py",
    "materialize_reviewer_reuse_20260822.py",
    "audit_reviewer_minimum33_preflight_20260823.py",
    "evaluate.py",
}
for f in INV["files"]:
    name = os.path.basename(f["path"])
    if name.endswith(".py"):
        if name in {"models.py", "reviewer_baselines.py"}:
            continue  # already copied from src/
        src = os.path.join(PROJ, "scripts", name) if os.path.exists(os.path.join(PROJ, "scripts", name)) else os.path.join(PROJ, name)
        dst = os.path.join(PKG, "scripts" if "scripts" in src else "code", name)
        if "scripts" in src:
            add(src, dst)
        elif name in ROOT_SCRIPTS:
            add(src, dst)
    elif name.endswith(".ps1"):
        add(f["path"], os.path.join(PKG, "code", name))

print("== code: ps1 runners (B15 batch + minimum33) ==")
for name in ["manage_protocol_v2_formal_queue_20260815.ps1",
             "run_reviewer_minimum33_stage_20260823.ps1",
             "manage_reviewer_minimum33_queue_20260823.ps1",
             "run_reviewer_minimum33_smoke_20260823.ps1",
             "run_reviewer_minimum33_postanalysis_20260823.ps1",
             "resume_reviewer_minimum33_stage_20260826.ps1"]:
    p = os.path.join(PROJ, name)
    if os.path.exists(p):
        add(p, os.path.join(PKG, "code", name))

print("== code: supporting scripts ==")
SUPPORT = ["build_protocol_v2_subject_grouped_windows.py", "build_forecasting_windows.py",
           "extract_amass_joints.py", "analyze_amass_dataset.py",
           "launch_extract_amass.py", "launch_build_windows.py",
           "audit_data_leakage_and_protocol.py", "audit_protocol_v2_readiness.py",
           "runtime_smoke_protocol_v2_models.py", "smoke_test_protocol_v2_data.py",
           "audit_protocol_v2_revision_20260821.py", "audit_protocol_v2_supplementary_20260820.py"]
for name in SUPPORT:
    p = os.path.join(PROJ, "scripts", name)
    if os.path.exists(p):
        add(p, os.path.join(PKG, "scripts", name))

print("== configs ==")
add(os.path.join(PROJ, r"configs\amass_preprocess.example.json"),
    os.path.join(PKG, "configs", "amass_preprocess.example.json"))

print("== protocol (B33) ==")
add(os.path.join(B33, "formal_reviewer_minimum33_plan.json"), os.path.join(PKG, "protocol", "formal_reviewer_minimum33_plan.json"))
add(os.path.join(B33, "formal_start_authorization.json"), os.path.join(PKG, "protocol", "formal_start_authorization.json"))
add(os.path.join(B33, "postanalysis_state.json"), os.path.join(PKG, "protocol", "postanalysis_state.json"))
add(os.path.join(B33, "queue_state.json"), os.path.join(PKG, "protocol", "queue_state.json"))
add(os.path.join(B33, r"reused\reused_inventory.json"), os.path.join(PKG, "protocol", "reused_inventory.json"))
add(os.path.join(B33, r"audit\reviewer_minimum_audit_pass.json"), os.path.join(PKG, "protocol", "audit", "reviewer_minimum_audit_pass.json"))
add(os.path.join(B33, r"audit\postanalysis_warning_recovery_20260915.json"), os.path.join(PKG, "protocol", "audit", "postanalysis_warning_recovery_20260915.json"))
for e in os.scandir(os.path.join(B33, "review")):
    if e.name.endswith(".json"):
        add(e.path, os.path.join(PKG, "protocol", "review", e.name))
n_stage = 0
for e in os.scandir(os.path.join(B33, "stage_state")):
    if e.name.endswith("_exit.json"):
        add(e.path, os.path.join(PKG, "protocol", "stage_state", e.name))
        n_stage += 1
print(f"  ({n_stage} stage exit states)")

print("== protocol (B15 batch) ==")
add(os.path.join(B15, "formal_execution_plan.json"), os.path.join(PKG, "protocol", "formal_execution_plan_20260815.json"))
n_stage15 = 0
for e in os.scandir(os.path.join(B15, "stage_state")):
    if e.name.endswith("_exit.json"):
        add(e.path, os.path.join(PKG, "protocol", "stage_state_20260815", e.name))
        n_stage15 += 1
print(f"  ({n_stage15} stage exit states)")
print("== protocol: dataset audits ==")
for ds in ["cmu", "kit", "bmlmovi"]:
    ad = os.path.join(B15, ds, "audit")
    for name in ["dataset_audit_pass.json", f"{ds}_physical_metrics.csv", f"{ds}_physical_metrics.json"]:
        p = os.path.join(ad, name)
        if os.path.exists(p):
            add(p, os.path.join(PKG, "protocol", "dataset_audit", name))

print("== manifests ==")
MP = os.path.join(PROJ, r"data\processed\protocol_v2_subject_grouped_rootrel_pose\manifests")
for name in ["candidate_subject_split_manifest.csv", "common18_graph.json", "freeze_record.json",
             "frozen_subject_grouped_sequence_manifest.csv", "protocol_v2_spec.json"]:
    add(os.path.join(MP, name), os.path.join(PKG, "manifests", name))
add(os.path.join(PROJ, r"data\processed\protocol_v2_subject_grouped_rootrel_pose\PROTOCOL_V2_BUILD_INVENTORY.json"),
    os.path.join(PKG, "manifests", "PROTOCOL_V2_BUILD_INVENTORY.json"))

print("== results: per-run histories (both batches) ==")
n_runs = 0
for batch, bname in [(B33, "formal_reviewer_minimum33_revision_20260823"),
                     (B15, "formal_protocol_v2_subject_grouped_rootrel_pose_20260815")]:
    for ds in os.scandir(batch):
        if not ds.is_dir() or ds.name in {"analysis", "audit", "logs", "progress", "stage_state",
                                          "review", "reused", "smoke", "smoke_analysis_fixture",
                                          "interrupted_stage_archive", "recovery_snapshots"}:
            continue
        for run in os.scandir(ds.path):
            if not run.is_dir():
                continue
            for fn in ["train_history.json", "results.json", "config.json"]:
                p = os.path.join(run.path, fn)
                if os.path.exists(p):
                    add(p, os.path.join(PKG, "results", bname, ds.name, run.name, fn))
            n_runs += 1
print(f"  ({n_runs} run dirs)")

print("== analysis outputs ==")
A33 = os.path.join(B33, "analysis")
for sub in ["sequence", "efficiency", "curves"]:
    for e in os.scandir(os.path.join(A33, sub)):
        if e.is_file():
            add(e.path, os.path.join(PKG, "analysis", "outputs", sub, e.name))

print("== analysis: figure 4 ==")
add(os.path.join(SUBMIT, "plot_figure4.py"), os.path.join(PKG, "analysis", "figure4", "plot_figure4.py"))
add(os.path.join(SUBMIT, "figure4_data_merged.json"), os.path.join(PKG, "analysis", "figure4", "figure4_data.json"))
for fn in ["Figure4_training_validation_trajectories.png",
           "Figure4_training_validation_trajectories.pdf",
           "Figure4_training_validation_trajectories.svg"]:
    add(os.path.join(SUBMIT, fn), os.path.join(PKG, "analysis", "figure4", fn))

print("== checkpoints (best.pt, separate archive) ==")
n_ckpt = 0
for batch, bname in [(B33, "formal_reviewer_minimum33_revision_20260823"),
                     (B15, "formal_protocol_v2_subject_grouped_rootrel_pose_20260815")]:
    for ds in os.scandir(batch):
        if not ds.is_dir():
            continue
        for run in os.scandir(ds.path):
            if not run.is_dir():
                continue
            p = os.path.join(run.path, "best.pt")
            if os.path.exists(p):
                add(p, os.path.join(PKG, "checkpoints", bname, ds.name, run.name, "best.pt"), checkpoint=True)
                n_ckpt += 1
print(f"  ({n_ckpt} checkpoints)")

with open(os.path.join(PKG, "package_manifest.json"), "w", encoding="utf-8") as f:
    json.dump({"generated_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
               "files": MANIFEST}, f, indent=1)
with open(os.path.join(PKG, "checkpoints_manifest.json"), "w", encoding="utf-8") as f:
    json.dump({"generated_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
               "files": CHECKPOINT_MANIFEST}, f, indent=1)
print(f"\nDONE: {len(MANIFEST)} package files, {len(CHECKPOINT_MANIFEST)} checkpoints")
